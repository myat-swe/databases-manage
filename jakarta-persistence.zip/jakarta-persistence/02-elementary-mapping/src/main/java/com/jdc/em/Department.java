package com.jdc.em;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Department {

	private int id;
	private String name;
}
