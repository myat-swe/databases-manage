package com.jdc.jdbc.app.domain;






@SuppressWarnings("unused")
public class Employee {

	
	private int id;
	private String name;
	private double salary;
	private String phone;
	private int deaprtmentId;
}
