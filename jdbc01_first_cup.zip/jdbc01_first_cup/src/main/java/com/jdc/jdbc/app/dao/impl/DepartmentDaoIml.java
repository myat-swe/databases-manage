package com.jdc.jdbc.app.dao.impl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.jdc.jdbc.app.DbConnector;
import com.jdc.jdbc.app.dao.DepartmentDao;
import com.jdc.jdbc.app.domain.Department;

public class DepartmentDaoIml implements DepartmentDao{

	@Override
	public int create(String name) {
		
		
		return 0;
	}

	@Override
	public int update(String newName, int id) {
		final String sql = "update department set name = ? where id = ?";
		int updatedCount = 0;
		try (var conn = DbConnector.getDbConnection();
				var stmt =  conn.prepareStatement(sql)){
			//set parameters
			stmt.setString(1, newName);
			stmt.setInt(2, id);
			updatedCount = stmt.executeUpdate();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return updatedCount > 0 ? id : 0;
		
	}

	@Override
	public void delete(int id) {
		final String sql = "delete from department where id = ?";
		
	}
	@Override
	public Department findById(int id) {
		final String sql = "select d.id dep_id,d.name dep_name from department d where id=%d".formatted(id);
		
		try(var conn = DbConnector.getDbConnection();
				var stmt = conn.createStatement()){
			
			var rs = stmt.executeQuery(sql);
			
			
		
			
			while(rs.next()) {
				var department = new Department();
				department.setId(rs.getInt("dep_id"));
				department.setName(rs.getString("dep_name"));
				return department;
			}
			
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return null;
	}

	@Override
	public List<Department> findAll() {
		var result  = new ArrayList<Department>();
		final String sql = "select * from department";
		try(var conn = DbConnector.getDbConnection();
				var stmt = conn.createStatement()){
			var rs = stmt.executeQuery(sql);
			while(rs.next()) {
				var department = new Department();
				department.setId(rs.getInt("id"));
				department.setName(rs.getString("name"));
				result.add(department);
			}
		
			
		}catch(SQLException e) {
			
		}
		
		
		return result;
	}

}
