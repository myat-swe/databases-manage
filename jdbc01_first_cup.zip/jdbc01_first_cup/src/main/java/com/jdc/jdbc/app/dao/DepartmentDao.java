package com.jdc.jdbc.app.dao;

import java.util.List;

import com.jdc.jdbc.app.domain.Department;

public interface DepartmentDao {

	int create(String name);
	int update(String newName,int id);
	void delete(int id);
	Department findById(int id);
	List<Department> findAll();
}
