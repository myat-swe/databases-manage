package com.jdc.ml.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public interface ConnectionManager {

	String USER = "root";
	String URL = "jdbc:mysql://localhost:3306/student1_db";
	String PASS = "admin";
	Connection getConnection() throws SQLException;
	public static ConnectionManager getInstance() {
		return () -> DriverManager.getConnection(URL, USER, PASS);
	}
}
