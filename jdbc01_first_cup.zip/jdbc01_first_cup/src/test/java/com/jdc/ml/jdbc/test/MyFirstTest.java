package com.jdc.ml.jdbc.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.jdc.ml.jdbc.ConnectionManager;
import com.jdc.ml.jdbc.MyFirstDao;

class MyFirstTest {

	@Test
	void test() {
		var dao = new MyFirstDao(ConnectionManager.getInstance());
		var result = dao.getCourseCount();
		assertEquals(4, result);
		
	}

}
