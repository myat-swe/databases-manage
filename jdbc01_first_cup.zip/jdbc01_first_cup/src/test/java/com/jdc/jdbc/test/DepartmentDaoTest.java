package com.jdc.jdbc.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import com.jdc.jdbc.app.DbInitializer;
import com.jdc.jdbc.app.dao.DepartmentDao;
import com.jdc.jdbc.app.dao.impl.DepartmentDaoIml;
import com.jdc.jdbc.app.domain.Department;

@TestMethodOrder(OrderAnnotation.class)
public class DepartmentDaoTest {
	
	static DepartmentDao depDao;
	
	@ParameterizedTest
	@CsvSource({"Sales, 2", "Human Resources, 1"})
	void test_for_update(String nameForUpdate, int id) {
		var updateId = depDao.update(nameForUpdate, id);
		if(updateId > 0) {
			var department = depDao.findById(updateId);
			assertAll(() -> {
				assertNotNull(updateId);
				assertEquals(id, department.getId());
				assertEquals(nameForUpdate, department.getName());
			});
		}
	}
	
	
	@ParameterizedTest
	@ValueSource(ints = 3)
	void test_for_fintByAll(int expected) {
		var list = depDao.findAll();
		assertEquals(expected, list.size());
	}
	
	@ParameterizedTest
	@CsvSource(value = {
			"1, HR",
			"2, Sale",
			"3, Marketing"
	})
	@SuppressWarnings("unused")
	void test_for_fingById(int givenId,String expectedName) {
		
		
		depDao = new DepartmentDaoIml();
		
		Department dep = depDao.findById(
				givenId);
		
		
	}
	@BeforeAll
	static void setUpBeforeClass() {
		DbInitializer.drop("employee","department");
		DbInitializer.create();
		DbInitializer.init();
		depDao = new DepartmentDaoIml();
	}
	
}
